import{r}from"./request-DuP1Zchu.js";function e(){return r.get("/categories")}export{e as g};
