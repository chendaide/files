import{r}from"./request-Bzktf-xb.js";function e(){return r.get("/categories")}export{e as g};
