import{r}from"./request-DWP6FJ8c.js";function e(){return r.get("/categories")}export{e as g};
