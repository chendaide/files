import{r as t}from"./request-CvKnjr-W.js";function r(r){return t.post("/verification/submit",r)}function i(){return t.get("/verification/status")}export{i as g,r as s};
