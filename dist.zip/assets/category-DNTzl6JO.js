import{r}from"./request-CvKnjr-W.js";function e(){return r.get("/categories")}export{e as g};
