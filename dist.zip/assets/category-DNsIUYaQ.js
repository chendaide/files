import{r}from"./request-mBcj0uCQ.js";function e(){return r.get("/categories")}export{e as g};
