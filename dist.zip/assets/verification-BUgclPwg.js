import{r as t}from"./request-BNsejqU6.js";function r(r){return t.post("/verification/submit",r)}function i(){return t.get("/verification/status")}export{i as g,r as s};
