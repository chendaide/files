import{r}from"./request-cwRnarsF.js";function e(){return r.get("/categories")}export{e as g};
