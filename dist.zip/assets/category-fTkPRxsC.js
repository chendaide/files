import{r}from"./request-B-dZuzRO.js";function e(){return r.get("/categories")}export{e as g};
