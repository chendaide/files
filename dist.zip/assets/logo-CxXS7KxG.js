const o="/logo.png";export{o as _};
