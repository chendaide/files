import{r}from"./request-CmfXGNPW.js";function e(){return r.get("/categories")}export{e as g};
