import os
import sys
from flask import Flask, request, jsonify
from PIL import Image
import numpy as np

app = Flask(__name__)

# 延迟加载模型
model = None

def load_nsfw_model():
    global model
    if model is None:
        print("正在加载 NSFW 检测模型...")
        import opennsfw2 as n2
        model = n2.make_open_nsfw_model()
        print("模型加载完成")
    return model

# 默认敏感内容阈值
DEFAULT_THRESHOLD = {
    'porn': 0.7,
    'hentai': 0.7,
    'sexy': 0.9
}

@app.route('/check', methods=['POST'])
def check_image():
    if 'file' not in request.files:
        return jsonify({"error": "没有文件上传"}), 400
    
    # 获取自定义阈值
    thresholds = DEFAULT_THRESHOLD.copy()
    try:
        if 'threshold_porn' in request.form:
            thresholds['porn'] = float(request.form.get('threshold_porn'))
        if 'threshold_hentai' in request.form:
            thresholds['hentai'] = float(request.form.get('threshold_hentai'))
        if 'threshold_sexy' in request.form:
            thresholds['sexy'] = float(request.form.get('threshold_sexy'))
    except ValueError:
        pass

    file = request.files['file']
    script_dir = os.path.dirname(os.path.abspath(__file__))
    temp_path = os.path.join(script_dir, 'temp_upload.jpg')
    file.save(temp_path)
    
    try:
        import opennsfw2 as n2
        
        nsfw_model = load_nsfw_model()
        pil_image = Image.open(temp_path)
        image = n2.preprocess_image(pil_image, n2.Preprocessing.YAHOO)
        predictions = nsfw_model.predict(np.expand_dims(image, axis=0), verbose=0)
        sfw_score = float(predictions[0][0])
        nsfw_score = float(predictions[0][1])
        
        scores = {
            "drawings": 0.0,
            "hentai": nsfw_score * 0.3,
            "neutral": sfw_score,
            "porn": nsfw_score * 0.5,
            "sexy": nsfw_score * 0.2
        }
        
        is_safe = True
        reason = None
        min_threshold = min(thresholds['porn'], thresholds['hentai'], thresholds['sexy'])
        
        if nsfw_score >= min_threshold:
            is_safe = False
            reason = f"检测到不良内容 (NSFW分数: {nsfw_score:.2f})"
        
        return jsonify({
            "safe": is_safe,
            "scores": scores,
            "nsfw_score": nsfw_score,
            "reason": reason,
            "thresholds": thresholds
        })
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500
    
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({"status": "ok", "model": "opennsfw2"})

if __name__ == '__main__':
    port = 5000
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            pass
    
    print(f"Starting NSFW detection service on port {port}...")
    app.run(host='0.0.0.0', port=port)
